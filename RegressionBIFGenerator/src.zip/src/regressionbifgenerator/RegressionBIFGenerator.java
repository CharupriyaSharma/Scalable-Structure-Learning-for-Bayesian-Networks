/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regressionbifgenerator;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.BitSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author gross
 */
public class RegressionBIFGenerator {

    private final int maximumDegree;
    private final int numberOfParents;
    private final int numberOfRegressionTerms;
    private final File outputFile;
    private final Random rng;
    private final Set<BitSet> regressionTerms;
    private final Map<BitSet, Integer> probabilities;

    public RegressionBIFGenerator(int maximumDegree, int numberOfParents, int numberOfRegressionTerms, File outputFile) {
        this.maximumDegree = Math.min(maximumDegree, numberOfParents);
        this.numberOfParents = numberOfParents;
        this.numberOfRegressionTerms = (int) Math.min(numberOfRegressionTerms, Math.pow(2, numberOfParents));
        this.outputFile = outputFile;
        this.rng = new Random();
        this.regressionTerms = new HashSet<>();
        this.probabilities = new HashMap<>();
    }

    public void generate() {
        for (int i = 0; i < numberOfRegressionTerms; i++) {
            boolean failure;
            BitSet regressionTerm;
            do {
                regressionTerm = generateRegressionTerm();
                failure = !regressionTerms.add(regressionTerm);
            } while (failure);
            probabilities.put(regressionTerm, generateProbability());
        }
        writeBIFFile();
    }

    protected BitSet generateRegressionTerm() {
        BitSet result = new BitSet(numberOfParents);
        int degree = rng.nextInt(maximumDegree) + 1;
        for (int i = 0; i < degree; i++) {
            boolean failure = true;
            do {
                int candidate = rng.nextInt(numberOfParents);
                failure = result.get(candidate);
                result.set(candidate);
            } while (failure);
        }
        return result;
    }

    protected int generateProbability() {
        return (rng.nextInt(99) + 1);
    }

    protected void writeBIFFile() {
        try (FileWriter writer = new FileWriter(outputFile)) {
            writer.write("network unknown {\n");
            writer.write("}\n");
            for (int i = 0; i <= numberOfParents; i++) {
                writer.write("variable x" + i + " {\n");
                writer.write("  type discrete [ 2 ] { 0, 1 };\n");
                writer.write("}\n");
            }
            for (int i = 1; i <= numberOfParents; i++) {
                writer.write("probability ( x" + i + " ) {\n");
                writer.write("  table 0.5, 0.5;\n");
                writer.write("}\n");
            }            
            writer.write("probability ( x0 | ");
            for (int i = 1; i <= numberOfParents; i++) {
                writer.write("x" + i);
                if (i < numberOfParents) {
                    writer.write(", ");
                }
            }
            writer.write(" ) {\n");
            for (int i = 0; i < Math.pow(2, numberOfParents); i++) {
                BitSet bitset = BitSet.valueOf(new long[] {i} );
                System.out.println(bitset);
                writer.write("  (");
                for (int j = 0; j < numberOfParents; j++) {
                    if (bitset.get(j)) {
                        writer.write("1");
                    } else {
                        writer.write("0");
                    }
                    if (j < numberOfParents-1) {
                        writer.write(", ");
                    }
                }
                if (probabilities.containsKey(bitset)) {
                    writer.write(String.format(") 0.%1$d, 0.%2$d;\n", 100 - probabilities.get(bitset), probabilities.get(bitset)));
                } else {
                    writer.write(") " + (1) + ", " + 0 + ";\n");
                }
            }
            writer.write("}\n");
            //probability ( DrivHist | DrivingSkill, RiskAversion ) {
            //(SubStandard, Psychopath) 0.001, 0.004, 0.995;
            writer.flush();
        } catch (IOException ex) {
            Logger.getLogger(RegressionBIFGenerator.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void printRegressionTerms() {
        for (BitSet regressionTerm : regressionTerms) {
            System.out.println(regressionTerm);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        if (args.length < 4) {
            System.out.println("Error: Four parameters needed: # parents, # regression terms, maximum degree of interaction terms, output file name.");
        }
        System.out.println("# parents = " + args[0]);
        int numberOfParents = Integer.parseInt(args[0]);
        System.out.println("# regression terms = " + args[1]);
        int numberOfRegressionTerms = Integer.parseInt(args[1]);
        System.out.println("Maximum degree of interaction terms = " + args[2]);
        int maximumDegree = Integer.parseInt(args[2]);
        File outputFile = new File(args[3]);
        System.out.println("Output file: " + outputFile.getAbsolutePath());
        System.out.print("Generating network...");
        RegressionBIFGenerator generator = new RegressionBIFGenerator(maximumDegree, numberOfParents, numberOfRegressionTerms, outputFile);
        generator.generate();
        //generator.printRegressionTerms();
        System.out.println(" done.");
    }
}
